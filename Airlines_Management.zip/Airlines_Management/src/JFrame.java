
public class JFrame {

	public static final String DISPOSE_ON_CLOSE = null;

}
